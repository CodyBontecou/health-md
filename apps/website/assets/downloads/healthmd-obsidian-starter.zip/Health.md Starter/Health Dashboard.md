# Four weeks, a little more context

[[Start here]] · [[Reviews/2026-10-19 Weekly review|Read a weekly review]] · [[Guides/Use your own data|Use your own data]]

> [!note] Fictional sample · September 28 – October 25, 2026
> These are made-up measurements, not goals. The three charts below are **fixed snapshots** of the sample; they do not change when you edit notes. For updating charts, see [[Guides/Optional interactive charts]].

| Across four weeks | Value | Observed days |
| --- | ---: | ---: |
| Total steps | 249,630 | 28/28 |
| Average sleep | 7.49 hours | 27/28 |
| Average resting heart rate | 59.81 bpm | 27/28 |

Each average includes only the days with that measurement. October 8 has no sleep value; October 15 has no resting-heart-rate value.

## Daily steps

![[Attachments/steps.svg]]

## Sleep duration

![[Attachments/sleep_total_hours.svg]]

## Resting heart rate

![[Attachments/resting_heart_rate.svg]]

Sleep refers to the night beginning on the note's date. Lines break where values are missing. Narrow vertical scales on line charts show variation, not a health score.

## Explore the notes

This live table uses Obsidian's core **Bases** plugin. It reads the daily notes and updates if you edit them. Enable Bases in Settings if needed.

![[Views/Health log.base#All days]]

## All sample values

This fixed table is also available without Bases. Open a date to read its fictional journal context. A dash means missing.

| Date | Steps | Sleep (hours) | Resting HR (bpm) |
| --- | ---: | ---: | ---: |
| [[Health/2026-09-28\|2026-09-28]] | 6,420 | 7.25 | 61 |
| [[Health/2026-09-29\|2026-09-29]] | 8,150 | 7.50 | 60 |
| [[Health/2026-09-30\|2026-09-30]] | 7,230 | 6.75 | 62 |
| [[Health/2026-10-01\|2026-10-01]] | 9,100 | 7.10 | 61 |
| [[Health/2026-10-02\|2026-10-02]] | 5,680 | 6.40 | 63 |
| [[Health/2026-10-03\|2026-10-03]] | 12,340 | 8.20 | 59 |
| [[Health/2026-10-04\|2026-10-04]] | 7,840 | 7.80 | 60 |
| [[Health/2026-10-05\|2026-10-05]] | 7,540 | 7.40 | 60 |
| [[Health/2026-10-06\|2026-10-06]] | 8,920 | 7.60 | 59 |
| [[Health/2026-10-07\|2026-10-07]] | 6,300 | 6.90 | 62 |
| [[Health/2026-10-08\|2026-10-08]] | 9,850 | — | 60 |
| [[Health/2026-10-09\|2026-10-09]] | 7,020 | 7.30 | 61 |
| [[Health/2026-10-10\|2026-10-10]] | 14,200 | 8.10 | 58 |
| [[Health/2026-10-11\|2026-10-11]] | 8,640 | 7.90 | 59 |
| [[Health/2026-10-12\|2026-10-12]] | 8,120 | 7.50 | 60 |
| [[Health/2026-10-13\|2026-10-13]] | 9,340 | 7.70 | 59 |
| [[Health/2026-10-14\|2026-10-14]] | 6,890 | 6.60 | 62 |
| [[Health/2026-10-15\|2026-10-15]] | 10,120 | 7.20 | — |
| [[Health/2026-10-16\|2026-10-16]] | 7,450 | 7.40 | 60 |
| [[Health/2026-10-17\|2026-10-17]] | 13,180 | 8.30 | 58 |
| [[Health/2026-10-18\|2026-10-18]] | 8,720 | 7.80 | 59 |
| [[Health/2026-10-19\|2026-10-19]] | 8,450 | 7.60 | 59 |
| [[Health/2026-10-20\|2026-10-20]] | 9,630 | 7.80 | 58 |
| [[Health/2026-10-21\|2026-10-21]] | 7,210 | 6.90 | 61 |
| [[Health/2026-10-22\|2026-10-22]] | 10,480 | 7.40 | 59 |
| [[Health/2026-10-23\|2026-10-23]] | 7,820 | 7.50 | 60 |
| [[Health/2026-10-24\|2026-10-24]] | 13,840 | 8.20 | 57 |
| [[Health/2026-10-25\|2026-10-25]] | 9,150 | 8.00 | 58 |

## Turn numbers into a review

Read the [[Reviews/2026-10-19 Weekly review|completed review]], then use [[Templates/Weekly review|the weekly template]] for your own dates. Ask what changed in daily life before interpreting a chart.

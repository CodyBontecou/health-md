---
type: weekly-review
week_start: 2026-10-19
week_end: 2026-10-25
sample_data: true
tags:
  - health/review
  - health/sample
---

# A week with more room to walk

October 19–25, 2026 · [[Health Dashboard|Dashboard]] · [[Templates/Weekly review|Use this structure next week]]

> [!note] A fictional example, already filled in
> All measurements and reflections are made up. The summary below was calculated from the sample notes when the starter was built; the prose and summary table do not update automatically.

## 1. Check coverage

This week has seven observations for each metric. The previous week is October 12–18 and has only six resting-heart-rate observations: [[Health/2026-10-15|October 15]] is missing. No value was filled in for that day.

| Metric | This week | Previous week | Observed days: this · previous |
| --- | ---: | ---: | --- |
| Total steps (steps) | 66,580 | 63,820 | 7/7 · 7/7 |
| Average sleep duration (hours) | 7.63 | 7.50 | 7/7 · 7/7 |
| Average resting heart rate (bpm) | 58.86 | 59.67 | 7/7 · 6/7 |

Average sleep and resting heart rate are unweighted means of the observed daily summaries, not pooled raw-sample calculations. The differing resting-heart-rate coverage makes that comparison less complete.

### Look at this week's source notes

![[Views/Health log.base#Review week]]

If Bases is disabled, open [[Health/2026-10-19]], [[Health/2026-10-20]], [[Health/2026-10-21]], [[Health/2026-10-22]], [[Health/2026-10-23]], [[Health/2026-10-24]], and [[Health/2026-10-25]] directly.

## 2. Add the context

The lunch walks and Saturday outing gave this week a rhythm I enjoyed. Wednesday was still a later evening. I want the journal to help me remember those details rather than label the whole week good or bad from three averages.

The changes between weeks are descriptive. This little sample cannot tell me that walking caused a change in sleep or heart rate.

## 3. Choose one small action

- [ ] Put two lunch walks on next week's calendar.

At the next review, check whether I actually took them and whether the routine felt sustainable. The step total is context, not the only measure of success.

## 4. Leave a note for next time

Keep noting late evenings and device gaps on the day they happen. Review the coverage counts before comparing another week.
